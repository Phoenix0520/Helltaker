#include "framework.h"
#include "SceneList.h"
#include "Helltaker.h"
#include "ObjectList.h"

#define   CHAIN_VIEW   3
#define   CHAIN_END   25

HS17_BossScene::HS17_BossScene()
{
	wstring imageFile1 = L"./Images/Boss/Background (0).png";
	wstring shaderFile = L"./Shader/HLSL/TextureColor.hlsl";

	wstring str = L"./Images/1.png";

	rect = new Texture(imageFile1, shaderFile);
	rect->SetScale(1920.0f, 1080.0f);
	rect->UpdateColorBuffer(Color(0.775f, 0.175f, 0.045f, 0.725f), 4, 0, 0, 0);

	// 70, 6, 36 * x = 255, 55, 5
	// 70 * x = 255 / 70
	// 6 * x = 55 / 6
	// 36 * x = 5 / 36

	background[0] = new Texture(imageFile1, shaderFile);
	background[0]->SetScale(1.65f, 1.65f);
	background[0]->SetPosition(-525.0f, 0.0f);

	background[1] = new Texture(imageFile1, shaderFile);
	background[1]->SetScale(1.65f, 1.65f);
	background[1]->SetRotation(0.0f, 180.0f, 0.0f);
	background[1]->SetPosition(525.0f, 0.0f);

	outer = new BossOuter();
	outer->SetPosition(732.5f, 25.0f);

	chainVH = new ChainVH();
	chainDaigonal = new ChainDaigonal();

	SetActive(false);
	display = true;
	sceneName = "HS17_BossScene";
}

HS17_BossScene::~HS17_BossScene()
{
	SAFE_DELETE(background[0]);
	SAFE_DELETE(background[1]);
	SAFE_DELETE(outer);
}

void HS17_BossScene::Update()
{
	CAMERA->Update();
	Matrix V = CAMERA->GetViewMatrix();
	Matrix P = CAMERA->GetProjMatrix();


	background[0]->Update(V, P);
	background[1]->Update(V, P);

	rect->Update(V, P);

	outer->Update(V, P);

	chainVH->Update(V, P);
	chainDaigonal->Update(V, P);
	//OBJMANAGER->Update("Helltaker", V, P);
}

void HS17_BossScene::Render()
{
	background[0]->Render();
	background[1]->Render();
	rect->Render();

	outer->Render();


	chainVH->Render();
	chainDaigonal->Render();

	//OBJMANAGER->Render("Helltaker");

	DirectWrite::GetDC()->BeginDraw();
	{
		RECT rect = { 5, 5, 505, 505 };

		wstring str = L"FPS : " + to_wstring(TIMEMANAGER->GetFrame());
		DirectWrite::RenderText(str, rect);

		rect.top += 20;
		rect.bottom += 20;

		str = L"CameraPos(" + to_wstring(CAMERA->GetPosition().x) + L" , " + to_wstring(CAMERA->GetPosition().y) + L")";
		DirectWrite::RenderText(str, rect);

		rect.top += 20;
		rect.bottom += 20;

		Vector2 pos = mouse->GetPosition();
		CAMERA->WCToVC(pos);

		str = L"MousePos(" + to_wstring(pos.x) + L" , " + to_wstring(pos.y) + L")";
		DirectWrite::RenderText(str, rect);
	}
	DirectWrite::GetDC()->EndDraw();
}

void HS17_BossScene::ChangeScene()
{
	SetActive(true);

	cout << endl << "BossScene!";

	HS03_ChangeScene* scene = (HS03_ChangeScene*)SCENEMANAGER->GetScene("HS03_ChangeScene");
	scene->SetNextScene("HS17_BossScene");

	HTMAP->Clear();
	HTMAP->SetSize(9, 9);
	//HTMAP->SetOffset(-400.0f, 450.0f);
	HTMAP->SetOffset(-400.0f, 390.0f);
	OBJMANAGER->ClearObjectStrings();

	switch (stage)
	{
	case 1: SetScenario1(); break;
	case 2: SetScenario2(); break;
	default: break;
	}

	time = 0.0f;
	scenarioCount = 0;
	step = 0;

	ShowMap(-400.0f, 200.0f);

	// Move
	{
		HTMAP->SetMapValue(1, 1, 7);
		HTMAP->SetMapValue(2, 1, 7);
		HTMAP->SetMapValue(3, 1, 7);
		HTMAP->SetMapValue(4, 1, 7);
		HTMAP->SetMapValue(5, 1, 7);
		HTMAP->SetMapValue(6, 1, 7);
		HTMAP->SetMapValue(7, 1, 7);
	}

	// Trap
	{
		HTMAP->AssignTrap("Trap1", 1, 0);
		HTMAP->AssignTrap("Trap2", 2, 0);
		HTMAP->AssignTrap("Trap3", 3, 0);
		HTMAP->AssignTrap("Trap4", 4, 0);
		HTMAP->AssignTrap("Trap5", 5, 0);
		HTMAP->AssignTrap("Trap6", 6, 0);
		HTMAP->AssignTrap("Trap7", 7, 0);
										
		HTMAP->AssignTrap("Trap8",  1, 1);
		HTMAP->AssignTrap("Trap9",  2, 1);
		HTMAP->AssignTrap("Trap10", 3, 1);
		HTMAP->AssignTrap("Trap11", 4, 1);
		HTMAP->AssignTrap("Trap12", 5, 1);
		HTMAP->AssignTrap("Trap13", 6, 1);
		HTMAP->AssignTrap("Trap14", 7, 1);
										
		HTMAP->AssignTrap("Trap15", 1, 7);
		HTMAP->AssignTrap("Trap16", 2, 7);
		HTMAP->AssignTrap("Trap17", 3, 7);
		HTMAP->AssignTrap("Trap18", 4, 7);
		HTMAP->AssignTrap("Trap19", 5, 7);
		HTMAP->AssignTrap("Trap20", 6, 7);
		HTMAP->AssignTrap("Trap21", 7, 7);
										
		HTMAP->AssignTrap("Trap22", 1, 8);
		HTMAP->AssignTrap("Trap23", 2, 8);
		HTMAP->AssignTrap("Trap24", 3, 8);
		HTMAP->AssignTrap("Trap25", 4, 8);
		HTMAP->AssignTrap("Trap26", 5, 8);
		HTMAP->AssignTrap("Trap28", 7, 8);
		HTMAP->AssignTrap("Trap27", 6, 8);
	}

	// HT
	{
		HTMAP->AssignHelltaker(4, 4, 1000);
	}
}

void HS17_BossScene::ShowMap(float x, float y)
{
	OBJMANAGER->ClearObjectStrings();

	HTMAP->Clear();
	HTMAP->SetSize(9, 9);
	HTMAP->SetOffset(x, y);   // 200 250 300 

	// Move

	for (int i = 1; i < 8; i++)
	{
		for (int j = 0; j < 9; j++)
			HTMAP->SetValue(i, j, HTMAPSTATE::move, NULL);
	}


	// Trap
	for (int i = 1; i <= 7; i++)
	{
		string str = "Trap" + to_string(i);

		Trap *pTrap = (Trap*)OBJMANAGER->FindObject(str);

		if (y >= 260.0f)
		{
			pTrap->SetActive(true);
			HTMAP->AssignTrap(str, i, 0, 4);
		}

		else
		{
			pTrap->SetActive(true);
			HTMAP->AssignTrap(str, i, 0, 4);
		}

	}
	int id = 8;
	for (int i = 1; i <= 7; i++)
	{
		string str = "Trap" + to_string(id);

		if (y >= 230.0f  && y <= 250.0f)
		{
			HTMAP->AssignTrap(str, i, 1, 5);
			Trap *pTrap = (Trap*)OBJMANAGER->FindObject(str);
		}
		if (y >= 250.0f)
		{
			HTMAP->AssignTrap(str, i, 1, 4);
			Trap *pTrap = (Trap*)OBJMANAGER->FindObject(str);
		}
		id++;
	}


	for (int i = 1; i <= 7; i++)
	{
		string str = "Trap" + to_string(id);
		Trap *pTrap = (Trap*)OBJMANAGER->FindObject(str);

		if (y >= 280.0f && y <= 300.0f)
		{
			pTrap->SetActive(true);
			HTMAP->AssignTrap(str, i, 6, 5);
		}

		else if (y >= 200.0f)
		{
			pTrap->SetActive(true);
			HTMAP->AssignTrap(str, i, 6, 4);
		}
		id++;
	}

	for (int i = 1; i <= 7; i++)
	{
		string str = "Trap" + to_string(id);

		Trap *pTrap = (Trap*)OBJMANAGER->FindObject(str);
		if (y >= 210.0f)
			HTMAP->AssignTrap(str, i, 7, 4);

		id++;
	}
}

void HS17_BossScene::SetScenario1()
{
	scenarios.clear();

	const int RDY = 0;
	const int ATK = 1;
	const int VER = 0;
	const int HOR = 1;

	scenarios.push_back(Scenario{ RDY, 0x1000000 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x1000000 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0100000 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0100000 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0010000 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0010000 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0001000 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0001000 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000100 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000100 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000010 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000010 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000001 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000001 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000010 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000010 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000100 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000100 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0001000 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0001000 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0010000 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0010000 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0100000 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0100000 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x1000000 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x1000000 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x1001000 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x1001000 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0100100 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0100100 ,0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0010010 ,0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0010010 ,0x00000, 0.25f });

	scenarios.push_back(Scenario{ CHAIN_VIEW, 0x010010, 0x00000, 0.0f });
	scenarios.push_back(Scenario{ RDY, 0x0001001, 0x00000 ,0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0001001, 0x00000 ,0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0010010, 0x00000 ,0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0010010, 0x00000 ,0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0100100, 0x00000 ,0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0100100, 0x00000 ,0.25f });
	scenarios.push_back(Scenario{ RDY, 0x1001000, 0x00000 ,0.75f });
	scenarios.push_back(Scenario{ ATK, 0x1001000, 0x00000 ,0.25f });
	scenarios.push_back(Scenario{ CHAIN_END, 0x010010, 0x0000 , 50000.0f });
}

void HS17_BossScene::SetScenario2()
{
	scenarios.clear();

	const int RDY = 0;
	const int ATK = 1;
	const int VER = 0;
	const int HOR = 1;
	const int DAI = 25;

	scenarios.push_back(Scenario{ RDY, 0x1001001, 0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x1001001, 0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0100010, 0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0100010, 0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0001000, 0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0001000, 0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0100010, 0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0100010, 0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x1001001, 0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x1001001, 0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000000, 0x00001, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000000, 0x00001, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000000, 0x00010, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000000, 0x00010, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000000, 0x00100, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000000, 0x00100, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000000, 0x01000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000000, 0x01000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000000, 0x10000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000000, 0x10000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000000, 0x01000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000000, 0x01000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000000, 0x00100, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000000, 0x00100, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000000, 0x00010, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000000, 0x00010, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000000, 0x00001, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000000, 0x00001, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000000, 0x10001, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000000, 0x10001, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000000, 0x01010, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000000, 0x01010, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0000000, 0x10001, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0000000, 0x10001, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x1001001, 0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x1001001, 0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0100010, 0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0100010, 0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0001000, 0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0001000, 0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x0100010, 0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x0100010, 0x00000, 0.25f });
	scenarios.push_back(Scenario{ RDY, 0x1001001, 0x00000, 0.75f });
	scenarios.push_back(Scenario{ ATK, 0x1001001, 0x00000, 0.25f });

	scenarios.push_back(Scenario{ DAI, 0x0011000, 0x00000 ,50000.0f });
}

void HS17_BossScene::UpdateChain()
{
	if (scenarioCount >= scenarios.size())
		return;

	time += DELTA;

	Scenario p = scenarios[scenarioCount];

	if (time > p.time)
	{
		scenarioCount++;
		time = 0.0f;
	}

	Scenario p2 = scenarios[scenarioCount];
	if (p2.state == 0)
	{
		Helltaker *pObject = dynamic_cast<Helltaker*>(OBJMANAGER->FindObject("Helltaker"));
		pObject->ExternMoveObject(p2.vertical, p2.horizontal);
	}

	if (p.state == CHAIN_END || p.state == CHAIN_VIEW)
	{
		Bridge* bridge = (Bridge*)OBJMANAGER->FindObject("Bridge");
		bridge->SetMove(false);

		Chain* chain1 = (Chain*)OBJMANAGER->FindObject("Chain1");
		Chain* chain2 = (Chain*)OBJMANAGER->FindObject("Chain2");
		chain1->SetStop();
		chain2->SetStop();

		if (p.state == CHAIN_END)
			step = 2;

		chainVH->Reset();
		chainDaigonal->Reset();

		Helltaker *pObject = dynamic_cast<Helltaker*>(OBJMANAGER->FindObject("Helltaker"));
		Vector2    pos2 = pObject->GetPosition();
		POINT      pt = HTMAP->GetMapXY(pos2);

		ShowMap(-400.0f, 200.0f);

		chainDaigonal->SetActive(true);
		chainDaigonal->SetState(p.vertical);
		//	ChainDaigonal->SetGapY(pBridge->Gap());

		chainVH->SetActive(false);

		bridge->SetPosition(0.0f, -70.0f);
		bridge->Reset();

		HTMAP->SetValue(pt.x, pt.y, HTMAPSTATE::helltaker, pObject);
		Vector2 pos = HTMAP->GetPosition(pt.x, pt.y);
		pObject->SetPosition(pos);

		OBJMANAGER->AddObjectStrings("Helltaker");

		return;
	}

	chainVH->SetActive(true);
	chainVH->SetState(p.state);  // Ready, Attack
	chainVH->SetValue(p.vertical, p.horizontal);
}

void HS17_BossScene::UpdateBridge()
{
	Vector2 pos = HTMAP->GetOffset();

	Helltaker *pHelltaker = (Helltaker*)OBJMANAGER->FindObject("Helltaker");
	Vector2 pos2 = pHelltaker->GetPosition();

	pos2.y = pos2.y;
	POINT pt = HTMAP->GetMapXY(pos2);
	pos2.y = pos2.y + 1.5f;

	pos.y = pos.y + 1.5f;
	if (pos.y >= 290)
	{
		pos.y = 200.0f;
		//	pos2.y = pos2.y -200.0f;
		//	pHelltaker->SetPosition(pos2);
	}

	ShowMap(pos.x, pos.y);
	HTMAP->SetValue(pt.x, pt.y, HTMAPSTATE::helltaker, pHelltaker);
	OBJMANAGER->AddObjectStrings("Helltaker");
}

void HS17_BossScene::StartBridge()
{
	step = 1;

	Scenario p2 = scenarios[0];
	if (p2.state == 0)
	{
		Helltaker *pObject = dynamic_cast<Helltaker*>(OBJMANAGER->FindObject("Helltaker"));
		pObject->ExternMoveObject(p2.vertical, p2.horizontal);
	}
}

void HS17_BossScene::Sample()
{
	Matrix V = CAMERA->GetViewMatrix();
	Matrix P = CAMERA->GetProjMatrix();
}
