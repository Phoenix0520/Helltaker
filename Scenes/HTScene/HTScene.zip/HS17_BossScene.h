#pragma once

class HS17_BossScene : public Scene
{
public:
	HS17_BossScene();
	~HS17_BossScene();

public:
	struct  Scenario
	{
		int   state;     
		int   vertical;  
		int   horizontal;
		float time;      
	};


public: 
	void Update() override;
	void Render() override;
	void ChangeScene() override;
	// Update, Render

	void SetScenario1();
	void SetScenario2();

	void ShowMap(float x, float y);
	void UpdateChain();
	void UpdateBridge();
	void StartBridge();

	// Map Setting

	void Sample();

private:
	class Texture* background[5];
	class Texture* rect = nullptr;

	class BossOuter*		outer			= nullptr;
	class ChainVH*			chainVH			= nullptr;
	class ChainDaigonal*	chainDaigonal	= nullptr;


	int   step = 0;
	int   stage = 1;
	int   scenarioCount = 0;

	float time = 0.0f;
	float val = 0.0f;
	
	vector<Scenario> scenarios;
};